export const environment = {
    production: false,
    baseApiUrl:'http://localhost:58692'
}